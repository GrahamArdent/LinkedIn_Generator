from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
import os, yaml, json, re

from .llm import LLMClient, NoopLLMClient
from .schemas import PostJSON


def load_prompt_packs(config_dir: Path) -> Dict[str, Any]:
    path = config_dir / "prompts_packs.yaml"
    return yaml.safe_load(path.read_text(encoding="utf-8"))


# ---------- Safe formatting ----------
class _SafeDict(dict):
    """Returns '' for any missing key to avoid KeyError during .format_map()."""
    def __missing__(self, key):
        return ""


def _fmt(template: str, **kwargs) -> str:
    """Safe formatter: missing placeholders become empty strings."""
    return template.format_map(_SafeDict(**kwargs))


# ---------- LLM selection ----------
def _choose_client() -> LLMClient:
    # Use NOOP client unless explicitly disabled (default keeps things safe)
    if os.getenv("LLM_NOOP", "1") == "1":
        return NoopLLMClient()
    return LLMClient()


# ---------- Helpers ----------
def _coerce_json(s: str) -> Dict[str, Any]:
    """Parse JSON; if there's extra text, try to extract the first {...} block."""
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", s, flags=re.S)
        if not m:
            raise ValueError("LLM did not return valid JSON")
        return json.loads(m.group(0))


# ---------- Main LLM pipeline ----------
def generate_post_via_llm(config_dir: Path, context: Dict[str, Any]) -> PostJSON:
    packs = load_prompt_packs(config_dir)
    client = _choose_client()

    # Build a readable list of allowed research sources (titles)
    allowed_sources = context.get("allowed_sources", [])
    allowed_sources_str = ", ".join(allowed_sources) if allowed_sources else "None specified"

    # DRAFT
    draft_user = _fmt(
        packs["draft_prompt"]["user_template"],
        persona_key=context.get("persona_key", "graham"),
        voice=context.get("voice", ""),  # IMPORTANT: feed persona voice into prompt
        objective=context.get("objective", "Educate and provoke thoughtful discussion."),
        topic=context.get("topic", "identity security"),
        pillar=context.get("pillar", "trend_decode"),
        services=context.get("services", ["adversarial_simulation", "vulnerability_assessment"]),
        cta_allow=context.get("cta_allow", ["Comment CHECKLIST", "DM BOARD", "Reply VISHING"]),
        allowed_sources=allowed_sources_str,
        hashtags=" ".join(context.get("hashtags", ["#CyberSecurity", "#IdentitySecurity"])),
    )
    draft_text = client.call(packs["draft_prompt"]["system"], draft_user)

    # CRITIQUE
    critique_user = _fmt(packs["critique_prompt"]["user_template"], draft=draft_text)
    improved = client.call(packs["critique_prompt"]["system"], critique_user)

    # CONSTRAIN → JSON
    final_user = _fmt(packs["constrain_prompt"]["user_template"], text=improved)
    final_text = client.call(packs["constrain_prompt"]["system"], final_user)

    obj = _coerce_json(final_text)
    return PostJSON.parse_obj(obj)


def to_text(p: PostJSON) -> str:
    parts = [
        getattr(p, "hook", ""),
        getattr(p, "exec_pov", getattr(p, "pov", "")),  # support either exec_pov or pov
        getattr(p, "proof_point", ""),
        "\n".join(getattr(p, "micro_plays", [])),
        getattr(p, "quote", ""),
        getattr(p, "cta", ""),
        " ".join(getattr(p, "hashtags", [])),
    ]
    body = "\n\n".join([s for s in parts if s]).replace("—", "-").strip()
    return body


def sanitize_and_validate(text: str) -> str:
    text = text.replace("—", "-")
    tags = re.findall(r"#\w+", text)
    if len(tags) < 3:
        text = text.rstrip() + "\n#CyberSecurity #IdentitySecurity #ThirdPartyRisk"
    elif len(tags) > 5:
        # keep only first 5 at the end
        text = re.sub(r"(#\w+\s*)+$", "", text).strip() + "\n" + " ".join(tags[:5])
    return text
