"""App package for LinkedIn dual-persona posting system."""
