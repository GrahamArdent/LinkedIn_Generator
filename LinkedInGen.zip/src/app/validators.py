from __future__ import annotations
from typing import List, Dict, Any
import re
from urllib.parse import urlparse

FORBIDDEN_CTA_PHRASES = [
    "what security flaws",
    "how exposed are you",
    "share your vulnerabilities",
    "post your gaps",
    "are you vulnerable",
]

def enforce_no_links_in_body(text: str) -> str:
    text = re.sub(r"https?://\S+", "", text).strip()
    return text

def ensure_trusted_citations(citations: List[Dict[str, Any]], whitelist_domains: List[str]) -> None:
    def allowed(domain: str) -> bool:
        domain = (domain or "").lower()
        return any(domain.endswith(wd) for wd in whitelist_domains)
    bad = []
    for c in citations or []:
        url = c.get("url") or ""
        host = urlparse(url).hostname or ""
        if url and host and not allowed(host):
            bad.append((c.get("title",""), host))
    if bad:
        msg = "Untrusted citation domains:\n" + "\n".join([f"- {t or 'Untitled'} ({h})" for t,h in bad])
        raise ValueError(msg)

def validate_claims_and_cta(body: str, cta_text: str) -> None:
    lower = (body + " " + (cta_text or "")).lower()
    for phrase in FORBIDDEN_CTA_PHRASES:
        if phrase in lower:
            raise ValueError(f"Unsafe CTA/wording detected: '{phrase}'")

def clamp_hashtags(body: str, min_tags: int = 3, max_tags: int = 5) -> str:
    tags = re.findall(r"#\w+", body)
    if len(tags) < min_tags:
        missing = ["#CyberSecurity", "#IdentitySecurity", "#ThirdPartyRisk"]
        body = body.rstrip() + "\n" + " ".join(missing[: min_tags - len(tags)])
    elif len(tags) > max_tags:
        head = re.sub(r"(#\w+\s*)+$", "", body).strip()
        body = head + "\n" + " ".join(tags[:max_tags])
    return body

def pre_publish_checks(body: str, cta_text: str, citations: List[Dict[str, Any]], whitelist_domains: List[str]) -> str:
    ensure_trusted_citations(citations, whitelist_domains)
    validate_claims_and_cta(body, cta_text)
    body = clamp_hashtags(body)
    return body