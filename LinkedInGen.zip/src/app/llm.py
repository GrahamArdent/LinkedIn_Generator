from __future__ import annotations
from typing import Optional
import os, time

try:
    from openai import OpenAI, RateLimitError, APIError
except Exception:
    OpenAI = object  # type: ignore
    class RateLimitError(Exception): ...
    class APIError(Exception): ...

class LLMClient:
    def __init__(self, model: Optional[str] = None, timeout: Optional[int] = None):
        self.model = model or os.getenv("LLM_MODEL", "gpt-4o-mini")
        self.timeout = timeout or int(os.getenv("LLM_TIMEOUT_S", "60"))
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("Set OPENAI_API_KEY environment variable.")
        if OpenAI is object:
            raise RuntimeError("openai package not installed. Run: pip install openai>=1.40")
        self.client = OpenAI(api_key=api_key)

    def call(self, system: str, user: str) -> str:
        backoff = 1.0
        for attempt in range(5):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{"role":"system","content":system},{"role":"user","content":user}],
                    temperature=0.5,
                    timeout=self.timeout,
                )
                return resp.choices[0].message.content.strip()
            except (RateLimitError, APIError):
                if attempt == 4:
                    raise
                time.sleep(backoff)
                backoff *= 2

class NoopLLMClient:
    def __init__(self, model: Optional[str] = None, timeout: Optional[int] = None):
        self.model = model or "noop"
        self.timeout = timeout or 0

    def call(self, system: str, user: str) -> str:
        return (
            '{"hook":"[noop hook]",'
            '"pov":"[noop pov]",'
            '"proof_point":"[noop proof]",'
            '"micro_plays":["a","b","c"],'
            '"quote":"[noop quote]",'
            '"cta":"[noop cta]",'
            '"hashtags":["#CyberSecurity","#IdentitySecurity","#ThirdPartyRisk"]}'
        )
