from __future__ import annotations
from pathlib import Path
from datetime import date
from typing import Dict, Any, Optional
import os

# dynamic hashtags
from .hashtags import generate_hashtags, ensure_hashtags_in_body

from .scheduler import load_schedule, resolve_persona_for_date
from .prompt_builder import build_prompt_blocks
from .research import pick_quote, pick_stat
from .composer import compose_post, build_carousel_from_text
from .validators import enforce_no_links_in_body, pre_publish_checks
from .citations import load_citations, pick_citations, load_whitelist, filter_to_whitelist
from .topics_loader import load_topics, select_topic_for
from .persona_logic import enrich_with_persona_rules
from .image_brief import make_carousel_brief
from .generation import generate_post_via_llm, to_text

BASE = Path(__file__).resolve().parents[2]
CONFIG = BASE / "config"
DATA = BASE / "data"


def _load_topics_local_then_env():
    """
    Load Graham and Ardent topics with these rules:

    1) Environment overrides win if present:
       - GRAHAM_TOPICS_CSV
       - ARDENT_TOPICS_CSV

    2) Otherwise, try local autodiscovery:
       - Graham: data/Graham_120Day_Final.csv
       - Ardent: support BOTH old and new naming patterns:
           * Ardent_12Week*.csv               (old)
           * ardent_*_schedule.csv            (new)
           * ardent*week*schedule*.csv        (new, flexible)
           * ardent_*schedule*.csv            (extra catch-all)

    Returns:
        (topics_graham: list[dict], topics_ardent: list[dict])
    """
    # --- Graham ---
    topics_graham = []
    g_env = os.getenv("GRAHAM_TOPICS_CSV")
    if g_env:
        topics_graham = load_topics(Path(g_env))
    else:
        g1 = DATA / "Graham_120Day_Final.csv"
        topics_graham = load_topics(g1) if g1.exists() else []

    # --- Ardent ---
    topics_ardent = []
    a_env = os.getenv("ARDENT_TOPICS_CSV")
    if a_env:
        topics_ardent = load_topics(Path(a_env))
    else:
        # Old pattern (still supported)
        old = sorted(DATA.glob("Ardent_12Week*.csv"), reverse=True)
        # Newer patterns (more flexible)
        new1 = sorted(DATA.glob("ardent_*_schedule.csv"), reverse=True)
        new2 = sorted(DATA.glob("ardent*week*schedule*.csv"), reverse=True)
        new3 = sorted(DATA.glob("ardent_*schedule*.csv"), reverse=True)

        ardent_candidates = (old or []) + (new1 or []) + (new2 or []) + (new3 or [])
        a1 = ardent_candidates[0] if ardent_candidates else None

        # Final fallback to the legacy file name if nothing matched
        if not a1:
            a1 = DATA / "Ardent_12Week_Filled_2025-09-23.csv"

        topics_ardent = load_topics(a1) if a1 and a1.exists() else []

    return topics_graham, topics_ardent


def _reply_prompts_from_templates(config_dir: Path):
    import yaml
    path = config_dir / "reply_prompt_templates.yaml"
    if not path.exists():
        return {"invite": [], "probe": [], "handoff": []}
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data.get("templates", {})


def generate_post(
    target_date: date,
    persona_key: Optional[str] = None,
    post_type: str = "text",
    use_llm: bool = False,
    override_topic: Optional[str] = None,
    crisis_mode: bool = False,
) -> Dict[str, Any]:
    schedule = load_schedule(CONFIG / "schedule.yaml")
    persona = persona_key or resolve_persona_for_date(schedule, target_date)
    if not persona:
        raise ValueError("No persona scheduled for this date.")

    blocks = build_prompt_blocks(CONFIG)
    quote = pick_quote(DATA)
    stat = pick_stat(DATA)
    all_cites = load_citations(DATA)
    whitelist = load_whitelist(CONFIG)

    topics_graham, topics_ardent = _load_topics_local_then_env()
    chosen = select_topic_for(target_date, persona, topics_graham, topics_ardent)

    topic_hint = stat.get("metric") if stat else None
    cites = pick_citations(all_cites, topic=topic_hint, max_items=2)
    cites = filter_to_whitelist(cites, whitelist)

    # Base draft via composer
    payload = compose_post(persona, blocks, quote, stat, citations=cites)

    # Record selected topic in metadata
    if override_topic:
        payload["metadata"]["selected_topic"] = override_topic
    elif chosen and chosen.get("topic"):
        payload["metadata"]["selected_topic"] = chosen["topic"]

    if crisis_mode:
        payload["metadata"]["mode"] = "crisis"
        payload["body"] = "Quick brief:\n" + payload["body"]

    # LLM pass (optional)
    if use_llm:
        # SAFE seed for LLM hashtags to avoid KeyError if a set is missing
        persona_block = blocks["personas"].get(persona, {})
        hashtag_set_key = persona_block.get("hashtag_set")
        hashtags_registry = blocks.get("hashtags", {})
        llm_hashtags_seed = hashtags_registry.get(
            hashtag_set_key, ["#CyberSecurity", "#InfoSec"]
        )

        ctx = {
            "persona_key": persona,
            "voice": persona_block.get("voice", ""),
            "objective": "Educate (Graham) or convert (Ardent) depending on persona.",
            "topic": payload["metadata"].get(
                "selected_topic",
                payload["metadata"].get("topic_key", "identity"),
            ),
            "pillar": payload["metadata"].get("inferred_pillar", "trend_decode"),
            "services": payload["metadata"].get("service_map", []),
            "cta_allow": persona_block.get("cta_patterns", []),
            "hashtags": llm_hashtags_seed,  # safe fallback
            "allowed_sources": [c.get("title") for c in cites if c.get("title")][:5],
        }
        post_json = generate_post_via_llm(CONFIG, ctx)
        payload["body"] = to_text(post_json)

    # Normalize links out of body
    payload["body"] = enforce_no_links_in_body(payload["body"])

    # --- Dynamic hashtags (post-aware, algo-tuned) ---
    topic_for_tags = (override_topic or None) or (chosen.get("topic") if chosen else None)
    dyn_tags = generate_hashtags(
        body_text=payload["body"],
        persona=persona,
        topic=topic_for_tags,
        config_dir=CONFIG,
    )
    payload["metadata"]["hashtags"] = dyn_tags
    payload["body"] = ensure_hashtags_in_body(payload["body"], dyn_tags)

    # First comment
    links = [c.get("url") for c in cites if c.get("url")]
    q1 = "Which control is most brittle in practice: identity, endpoints, or SaaS trust?"
    q2 = "Want the checklist? Say 'checklist' and I’ll DM it."
    first_comment = "\n".join([q1, q2, "", "Links:"] + links).strip()

    # Image brief for designers
    brief = make_carousel_brief(payload)
    payload["metadata"]["image_brief"] = brief

    # Reply prompts (DM/comment follow-ups)
    rtemps = _reply_prompts_from_templates(CONFIG)
    reply_prompts = {
        "invite": rtemps.get("invite", [])[:2],
        "probe": rtemps.get("probe", [])[:2],
        "handoff": rtemps.get("handoff", [])[:2],
    }

    # Optional doc carousel structure from text
    carousel = None
    if post_type == "doc_carousel":
        carousel = build_carousel_from_text(payload["body"])

    # Final guardrails (length/cta/citation checks)
    cta_text = blocks["personas"][persona]["cta_patterns"][0] if blocks["personas"][persona]["cta_patterns"] else ""
    payload["body"] = pre_publish_checks(payload["body"], cta_text, cites, whitelist)

    return {
        "persona": persona,
        "post_type": post_type,
        "body": payload["body"],
        "first_comment": first_comment,
        "citations": cites,
        "carousel": carousel,
        "reply_prompts": reply_prompts,
        "metadata": payload["metadata"],
    }
