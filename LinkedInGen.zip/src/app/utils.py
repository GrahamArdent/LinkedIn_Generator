from __future__ import annotations
from datetime import datetime, date
from typing import Dict, Any

def today_str(dt: date | None = None) -> str:
    return (dt or date.today()).isoformat()

def timestamp() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"
