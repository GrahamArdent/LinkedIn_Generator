# LinkedIn Dual-Persona Post System (Graham TL + Ardent Sales)

This repo generates LinkedIn-ready posts for two distinct personas on a fixed schedule:
- **Graham Hill (Thought Leadership)** — Mon, Wed, Fri
- **Ardent Security (Sales/Services)** — Tue, Thu

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
make test
python -m app.cli post --date 2025-10-08 --dry-run
```

## Structure
```
config/                 # YAML configs (personas, prompts, schedule, hashtags, pillars)
data/                   # Quotes & stats banks (CSV), examples
src/app/                # Python modules
tests/                  # Pytest unit tests
out/                    # Generated posts & metadata
logs/                   # Runtime logs
```

## Design Principles
- Config-first: update voices/schedule/CTAs without code changes.
- Guardrails: validators enforce tone, compliance, and CTA safety.
- Testable: small, typed functions with unit tests.
- Extensible: add a publisher later (e.g., n8n/Buffer/Sheets).

## CLI
- `python -m app.cli post [--date YYYY-MM-DD] [--persona graham_thought_leadership|ardent_sales] [--dry-run]`

Outputs:
- Markdown post in `out/` and a JSON metadata file.
- Optional carousel brief (JSON) for design workflow.


## Citations via Web Searches
Add rows to `data/citations.csv` with: topic,title,url,publisher,pub_date,note.
The generator appends up to two sources per post (configurable later). Keep domains credible (see `config/source_whitelist.yaml`).


## Topics from CSV (Next-Phase Automation)
Place or reference your planning sheets (e.g., `Graham_120Day_Final.csv`, `Ardent_12Week_Filled_2025-09-23.csv`).
The generator will:
- Detect date/topic/persona columns (loose schema).
- Select the topic matching the run date & persona.
- Enrich metadata (pillar, service map) and attach an image-brief JSON.

## Image Briefs (Scaffold)
`src/app/image_brief.py` returns a 4-slide carousel brief (titles + guidance). This is a bridge to a future image generator.


## LLM Pipeline (Draft → Critique → Constrain)
- Configure prompts in `config/prompts_packs.yaml`.
- Run with: `python -m app.cli post --llm --dry-run`
- Default is NOOP mode (does not call any external API). Set `LLM_NOOP=0` and implement your provider in `src/app/llm.py` to enable live calls.

### Provider wiring
Edit `LLMClient.call(...)` to integrate your SDK (OpenAI/Anthropic/etc.). Pass `system` and `user` as inputs and return the model's text.
