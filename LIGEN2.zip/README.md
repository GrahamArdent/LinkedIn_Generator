# LinkedInGen UI v1.1 (Minimal Streamlit + Backend)

Run:
```
pip install -r requirements.txt
streamlit run ui/app.py
```

Calendars: drop CSVs into `/data`. Any CSV with columns at least `topic, service` will be auto-discovered.
Aliases saved in `config/calendar_registry.json`.
